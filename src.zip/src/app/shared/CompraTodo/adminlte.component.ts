import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-adminlte',
  templateUrl: './adminlte.component.html',
  styleUrls: ['./adminlte.component.scss'],
})
export class AdminlteComponent  implements OnInit {

  constructor() { }

  ngOnInit() {}

}
