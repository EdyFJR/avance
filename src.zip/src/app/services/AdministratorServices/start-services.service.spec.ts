import { TestBed } from '@angular/core/testing';

import { StartServicesService } from './start-services.service';

describe('StartServicesService', () => {
  let service: StartServicesService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(StartServicesService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
