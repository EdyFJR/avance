import { Component, OnInit } from '@angular/core';
import { PopoverController } from '@ionic/angular';
import { PopuserComponent } from 'src/app/components/popuser/popuser.component';

@Component({
  selector: 'app-popover',
  templateUrl: './popover.page.html',
  styleUrls: ['./popover.page.scss'],
})
export class PopoverPage implements OnInit {

  constructor(private  popoverCtrl: PopoverController) { }

  ngOnInit() {
  }
  async mostratPop(){
    const popover = await this.popoverCtrl.create({
      component: PopuserComponent,
    });

    await popover.present();
  }

}
