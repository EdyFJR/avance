import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-superv',
  templateUrl: './superv.page.html',
  styleUrls: ['./superv.page.scss'],
})
export class SupervPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
