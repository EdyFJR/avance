import { ComponentFixture, TestBed } from '@angular/core/testing';
import { SupervPage } from './superv.page';

describe('SupervPage', () => {
  let component: SupervPage;
  let fixture: ComponentFixture<SupervPage>;

  beforeEach(async(() => {
    fixture = TestBed.createComponent(SupervPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
