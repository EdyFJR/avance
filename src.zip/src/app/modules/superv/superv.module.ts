import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { SupervPageRoutingModule } from './superv-routing.module';

import { SupervPage } from './superv.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    SupervPageRoutingModule
  ],
  declarations: [SupervPage]
})
export class SupervPageModule {}
