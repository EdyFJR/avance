import { Component, OnInit } from '@angular/core';
import { PopoverController } from '@ionic/angular';
import { PopuserComponent } from 'src/app/components/popuser/popuser.component';

@Component({
  selector: 'app-ofert-register',
  templateUrl: './ofert-register.page.html',
  styleUrls: ['./ofert-register.page.scss'],
})
export class OfertRegisterPage implements OnInit {

  constructor(private  popoverCtrl: PopoverController) { }

  ngOnInit() {
  }

  async mostratPop(){
    const popover = await this.popoverCtrl.create({
      component: PopuserComponent,
    });

    await popover.present();
  }

}