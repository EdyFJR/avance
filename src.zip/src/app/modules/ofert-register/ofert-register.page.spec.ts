import { ComponentFixture, TestBed } from '@angular/core/testing';
import { OfertRegisterPage } from './ofert-register.page';

describe('OfertRegisterPage', () => {
  let component: OfertRegisterPage;
  let fixture: ComponentFixture<OfertRegisterPage>;

  beforeEach(async(() => {
    fixture = TestBed.createComponent(OfertRegisterPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
