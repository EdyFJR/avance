import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { OfertRegisterPage } from './ofert-register.page';

const routes: Routes = [
  {
    path: '',
    component: OfertRegisterPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class OfertRegisterPageRoutingModule {}
