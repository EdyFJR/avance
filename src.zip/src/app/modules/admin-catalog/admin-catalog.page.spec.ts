import { ComponentFixture, TestBed } from '@angular/core/testing';
import { AdminCatalogPage } from './admin-catalog.page';

describe('AdminCatalogPage', () => {
  let component: AdminCatalogPage;
  let fixture: ComponentFixture<AdminCatalogPage>;

  beforeEach(async(() => {
    fixture = TestBed.createComponent(AdminCatalogPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
