import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admin-catalog',
  templateUrl: './admin-catalog.page.html',
  styleUrls: ['./admin-catalog.page.scss'],
})
export class AdminCatalogPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
