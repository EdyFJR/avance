import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { CheckSupplierPageRoutingModule } from './check-supplier-routing.module';

import { CheckSupplierPage } from './check-supplier.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    CheckSupplierPageRoutingModule
  ],
  declarations: [CheckSupplierPage]
})
export class CheckSupplierPageModule {}
