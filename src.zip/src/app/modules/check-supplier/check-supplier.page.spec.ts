import { ComponentFixture, TestBed } from '@angular/core/testing';
import { CheckSupplierPage } from './check-supplier.page';

describe('CheckSupplierPage', () => {
  let component: CheckSupplierPage;
  let fixture: ComponentFixture<CheckSupplierPage>;

  beforeEach(async(() => {
    fixture = TestBed.createComponent(CheckSupplierPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
