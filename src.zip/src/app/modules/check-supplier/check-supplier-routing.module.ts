import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { CheckSupplierPage } from './check-supplier.page';

const routes: Routes = [
  {
    path: '',
    component: CheckSupplierPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class CheckSupplierPageRoutingModule {}
