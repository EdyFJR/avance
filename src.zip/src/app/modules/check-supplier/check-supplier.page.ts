import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-check-supplier',
  templateUrl: './check-supplier.page.html',
  styleUrls: ['./check-supplier.page.scss'],
})
export class CheckSupplierPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
