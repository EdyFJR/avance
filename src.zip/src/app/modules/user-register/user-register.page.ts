import { Component, OnInit } from '@angular/core';
import { PopoverController } from '@ionic/angular';
import { PopuserComponent } from 'src/app/components/popuser/popuser.component';

@Component({
  selector: 'app-user-register',
  templateUrl: './user-register.page.html',
  styleUrls: ['./user-register.page.scss'],
})
export class UserRegisterPage implements OnInit {

  constructor(private  popoverCtrl: PopoverController) { }

  ngOnInit() {
  }

  async mostratPop(){
    const popover = await this.popoverCtrl.create({
      component: PopuserComponent,
    });

    await popover.present();
  }

}
