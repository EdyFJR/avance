import { NgModule } from '@angular/core';
import { PreloadAllModules, RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  {
    path: 'home',
    loadChildren: () => import('./home/home.module').then( m => m.HomePageModule)
  },
  {
    path: '',
    redirectTo: 'home',
    pathMatch: 'full'
  },
  // Routes to Administrator Pages
  {
    path: 'home',
    loadChildren: () => import('./pages/AdministratorPages/home/home.module').then( m => m.HomePageModule)
  },
  // Routes To home Pages
  {
    path: 'home',
    loadChildren: () => import('./pages/HomePages/home/home.module').then( m => m.HomePageModule)
  },
  {
    path: 'login',
    loadChildren: () => import('./pages/HomePages/login/login.module').then( m => m.LoginPageModule)
  },
  
  {
    path: 'user-register',
    loadChildren: () => import('./modules/user-register/user-register.module').then( m => m.UserRegisterPageModule)
  },
  {
    path: 'ofert-register',
    loadChildren: () => import('./modules/ofert-register/ofert-register.module').then( m => m.OfertRegisterPageModule)
  },
  {
    path: 'superv',
    loadChildren: () => import('./modules/superv/superv.module').then( m => m.SupervPageModule)
  },
  {
    path: 'admin-catalog',
    loadChildren: () => import('./modules/admin-catalog/admin-catalog.module').then( m => m.AdminCatalogPageModule)
  },
  {
    path: 'complaints',
    loadChildren: () => import('./modules/complaints/complaints.module').then( m => m.ComplaintsPageModule)
  },
  {
    path: 'check-supplier',
    loadChildren: () => import('./modules/check-supplier/check-supplier.module').then( m => m.CheckSupplierPageModule)
  },
  {
    path: 'chat',
    loadChildren: () => import('./modules/chat/chat.module').then( m => m.ChatPageModule)
  },  {
    path: 'popover',
    loadChildren: () => import('./modules/popover/popover.module').then( m => m.PopoverPageModule)
  },


];

@NgModule({
  imports: [
    RouterModule.forRoot(routes, { preloadingStrategy: PreloadAllModules })
  ],
  exports: [RouterModule]
})
export class AppRoutingModule { }
