import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-popuser',
  templateUrl: './popuser.component.html',
  styleUrls: ['./popuser.component.scss'],
})
export class PopuserComponent  implements OnInit {

  constructor() { }

  ngOnInit() {}

}
