import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-side-bar-component',
  templateUrl: './side-bar-component.component.html',
  styleUrls: ['./side-bar-component.component.scss'],
})
export class SideBarComponentComponent  implements OnInit {

  constructor() { }

  ngOnInit() {}

}
