import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home-interfaces',
  templateUrl: './home-interfaces.component.html',
  styleUrls: ['./home-interfaces.component.scss'],
})
export class HomeInterfacesComponent  implements OnInit {

  constructor() { }

  ngOnInit() {}

}
